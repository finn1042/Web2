const express = require('express');
const mysql = require('mysql');
const app = express();
const port = 3000;

// MySQL 连接
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '123456',
    database: 'crowdfunding_db'
});

db.connect(err => {
    if (err) throw err;
    console.log('MySQL Connected...');
});

// 搜索路由
app.get('/fundraisers/search', (req, res) => {
    const { organizer, city, categoryId } = req.query;

    let sql = 'SELECT * FROM fundraisers WHERE 1=1';
    const params = [];

    if (organizer) {
        sql += ' AND organizer = ?';
        params.push(organizer);
    }
    if (city) {
        sql += ' AND city = ?';
        params.push(city);
    }
    if (categoryId) {
        sql += ' AND category_id = ?';
        params.push(categoryId);
    }

    db.query(sql, params, (err, results) => {
        if (err) return res.status(500).send(err);
        res.json(results);
    });
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
