const express = require('express');
const cors = require('cors');
const mysql = require('mysql2');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('frontend')); // HTML文件夹

// 创建数据库连接
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', 
    password: '123456', 
    database: 'crowdfunding_db' 
});

// 连接到数据库
db.connect((err) => {
    if (err) {
        console.error('Error connecting to the database:', err);
        return;
    }
    console.log('Connected to the database');
});

// 获取所有活跃的筹款人
app.get('/fundraisers/active', (req, res) => {
    db.query('SELECT * FROM FUNDRAISER WHERE ACTIVE = TRUE', (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results);
    });
});

// 获取所有类别
app.get('/categories', (req, res) => {
    db.query('SELECT CATEGORY_ID, NAME FROM CATEGORY', (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results);
    });
});

// 搜索筹款人
app.get('/fundraisers/search', (req, res) => {
    const { city, categoryId } = req.query; // 移除 active 参数
    let query = `
        SELECT f.*, c.NAME AS category_name 
        FROM FUNDRAISER f 
        JOIN CATEGORY c ON f.CATEGORY_ID = c.CATEGORY_ID
    `;
    
    const conditions = [];
    const values = [];

    if (city) {
        conditions.push(`f.CITY = ?`);
        values.push(city);
    }
    if (categoryId) {
        conditions.push(`f.CATEGORY_ID = ?`);
        values.push(categoryId);
    }
    
    if (conditions.length) {
        query += ' WHERE ' + conditions.join(' AND ');
    }

    console.log('Executing query:', query);
    console.log('With values:', values);

    db.query(query, values, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results);
    });
});


// 根据ID获取筹款人的详细信息
app.get('/fundraiser/:id', (req, res) => {
    const fundraiserId = req.params.id;
    const query = `
        SELECT f.*, c.NAME AS category_name 
        FROM FUNDRAISER f 
        JOIN CATEGORY c ON f.CATEGORY_ID = c.CATEGORY_ID 
        WHERE f.FUNDRAISER_ID = ?
    `;
    
    db.query(query, [fundraiserId], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        if (results.length === 0) {
            return res.status(404).json({ message: 'Fundraiser not found' });
        }
        res.json(results[0]);
    });
});

// 启动服务器
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
